/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
using System;
class HelloWorld {
	private static int FindBandMember(int totalMembers, int[,] SwapMembers, int posMember)
	{
        int n = SwapMembers.GetLength(0);
        int[] result = new int[totalMembers];
        
        for(int i = 0; i < totalMembers; i++)
        {
            result[i] = i + 1;
        }
        
        for(int i = 0; i < n; i++)
        {
            int x = SwapMembers[i, 0];
            int y = SwapMembers[i, 1];
            int xpos = -1;
            int ypos = -1;
            for(int j = 0; j < totalMembers; j++)
            {
                if(result[j] == x)
                {
                    xpos = j;
                }
                else if(result[j] == y)
                {
                    ypos = j;
                }
            }
            result[ypos] = x;
            result[xpos] = y;
        }
        
        
        return result[posMember-1];
	}
	static void Main() {
		int totalMembers = 10;
		int SwapMembers_row = 2;   // Q = 2 performances
		int SwapMembers_col = 2;   // always 2 in this case
		int[,] SwapMembers = { {3, 7}, {6, 10}}; // 2D array for swaps
		int posMember = 5;
		Console.WriteLine(FindBandMember(totalMembers, SwapMembers, posMember));
	}
}